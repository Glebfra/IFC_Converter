﻿using System.Collections.Generic;
using IFCConverter.Importer.Interfaces;
using MathNet.Numerics.LinearAlgebra;
using Start.Interfaces;

namespace IFCConverter.Importer.Entities.Proxies
{
    internal class BoundaryProxy : IBoundaryProxy
    {
        public BoundaryProxy(IEntityProxy proxy, IReadOnlyCollection<Vector<double>> boundary)
        {
            Proxy = proxy;
            Boundary = boundary;
        }

        public IEntityProxy Proxy { get; }
        public IReadOnlyCollection<Vector<double>> Boundary { get; }
        
        public virtual IStartEntity ToStartEntity()
        {
            return Proxy.ToStartEntity();
        }
    }
}